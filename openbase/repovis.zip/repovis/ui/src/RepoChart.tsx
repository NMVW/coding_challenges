import React, { useEffect, useState } from 'react';

import 'frappe-charts/dist/frappe-charts.min.css';
import { Chart } from 'frappe-charts/dist/frappe-charts.esm.js';
import { FrappeTimeline, Timeline } from './interfaces';
import { fetchPRs, frappeTransformTimeline } from './api';

export default function RepoChartContainer() {

  const [ prTimeline, setPrTimeline ] = useState<FrappeTimeline | null>(null);
  const [ isLoading, setLoading ] = useState(false);

  async function fetch() {
    setLoading(true);
    // NOTE: since hardcoded to downshift repo, we know first PRs were in 2017 so fetch all years
    const { pr_timeline }: { pr_timeline: Timeline } = await fetchPRs([2021, 2020, 2019, 2018, 2017]);
    setPrTimeline(frappeTransformTimeline(pr_timeline));
    setLoading(false);
  }

  // on initial render
  useEffect(() => {
    fetch();
  }, []);

  return <RepoChart timeline={prTimeline} isLoading={isLoading} />;
}

const chartMetadata = {
  title: 'Downshift Pull Request Activity',
  type: 'bar',
  height: 500,
  colors: ['#f19e45', '#74f790'],
  axisOptions: {
    xAxisMode: 'tick',
    xIsSeries: true,
  },
  barOptions: {
    stacked: true,
    spaceRatio: 0.5,
  },
  tooltipOptions: {
    formatTooltipX: (d: number) => (d + '').toUpperCase(),
    formatTooltipY: (d: number) => d + ' pull requests',
  },
};

function RepoChart({ timeline, isLoading }: { timeline: FrappeTimeline | null, isLoading: boolean }) {

  const [ domNode, setNode ] = useState(null);
  const [ chart, setChart ] = useState(null);

  // on mount, init chart
  useEffect(() => {
    if (domNode && timeline) {
      const newChart = new Chart(domNode, {
        ...chartMetadata,
        data: timeline,
      });
      setChart(newChart);
    }
  }, [domNode, timeline]);

  // full new "data" object on timeline updates
  useEffect(() => {
    if (chart !== null) {
      (chart as any).update(timeline);
    }
  }, [timeline]);

  return (<div ref={node => node && setNode(node as any)} id="repo-chart" style={{width: '100%', height: '100%'}}></div>);
}
