import React from 'react';
import logo from './github_logo.png';
import './App.css';
import RepoChart from './RepoChart';

const repo_url = process.env.REACT_APP_GITHUB_REPO;

function App() {
  return (
    <div className="App">
      <img src={logo} className="App-logo" alt="logo" onClick={() => window.open(repo_url)} />
      <RepoChart />
    </div>
  );
}

export default App;
