import { MonthPRStats, Timeline } from './interfaces';

export const fetchPRs = (function (api_url) {
  return (years: number[]): Promise<{ pr_timeline: Timeline }> => fetch(`${api_url}/github-pr-timeline?years=${years.join(',')}`).then(res => res.json());
})(process.env.REACT_APP_API_URL);

const monthLabels = ['JAN', 'FEB', 'MAR', 'APR', 'MAY', 'JUN', 'JUL', 'AUG', 'SEP', 'OCT', 'NOV', 'DEC'];

export const frappeTransformTimeline = (timeline: Timeline) => {
  
  return Object.entries(timeline).reduce((chartData, [year, months]) => {
    // parse each month into a stacked bar chart with label

    // labels
    const labels = months.map((prs: MonthPRStats, index: number) => `${monthLabels[index]} ${year}`);
    chartData.labels.push(...labels);

    // datasets
    const openedCounts = months.map((prs: MonthPRStats) => prs ? prs[0]: 0);
    const closedCounts = months.map((prs: MonthPRStats) => prs ? prs[1]: 0);

    chartData.datasets[0].values.push(...openedCounts);
    chartData.datasets[1].values.push(...closedCounts);

    return chartData;

  }, {
    labels: [] as string[],
    datasets: [{ name: 'PRS opened', chartType: 'bar', values: [] as number[] }, { name: 'PRs closed', chartType: 'bar', values: [] as number[] }],
  });

}
