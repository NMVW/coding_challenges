// JAN => 0: [openedCount, closedCount]
export type MonthPRStats = Array<[number, number] | null>

export interface Timeline {
  [year: number]: MonthPRStats
}

export interface FrappeTimeline {
  labels: string[]
  datasets: Array<{ name: string, chartType: string, values: number[] }>
}