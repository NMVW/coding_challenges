/// <reference types="react-scripts" />
declare module 'frappe-charts/dist/frappe-charts.esm.js';