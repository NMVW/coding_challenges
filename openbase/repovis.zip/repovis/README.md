# Repo Visualizer

*HARDCODED* Single Github repo supported [downshift](https://github.com/downshift-js/downshift)

Upon page load, the user should see a stacked bar chart with the bars representing:

1. The total number of the project’s open pull requests at the last day of that month
2. The total number of the project’s closed pull requests at the last day of that month

-----------

## Dev Setup

In `ui/.env`, the `REACT_APP_API_URL` env var should point to your locally running `api` instance (express)
In `api/.env`, the `APP_DOMAIN` env var should point to your locally running `app` instance (react)

See respective READMEs in `api/` and `app/` directories for running the app (both components need to be running).

### Technical Specs
● ExpressJS backend powers the features listed
● React implements UI

![Goal](https://github.com/NMVW/repovis/blob/master/ui/mockup.png)
