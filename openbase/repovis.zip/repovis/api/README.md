# Github Repo API Proxy

Exposed endpoint returns opened / closed data for all months for given years.

```
GET /github-pr-timeline?years=<year1><year2>...

{
  [YEAR]: [
    [openedPRCount, closedPRCount],
    ...
  ]
  ...
}
```
Year-keyed arrays are 0-indexed for calendar month, 0 index => January.

Response data will return in-memory server cached results according to `API_TTL` (milliseconds). If cache is unset or expires, next inbound response will be delayed due to a full cache rebuild.

---------

## Env

Set environment variables in `api/` root.

`.env`
```
API_PORT=<exposed_express_port>
API_TTL=<milliseconds_cache_good_for>
GITHUB_GRAPHQL_API_URL=https://api.github.com/graphql
GITHUB_API_TOKEN=<super_secret_personal_api_token>
GITHUB_API_BACKOFF=<millisconds_between_subsequent_pagination_calls>
```

## Dev
1. Generate `GITHUB_GRAPHQL_TOKEN` via [Github API Token](https://docs.github.com/en/github/authenticating-to-github/creating-a-personal-access-token) with scope `repo.public_repo` only.
2. `npm install`
3. `npm run start:dev`

## Prod
1. Generate GitHub API Token for prod as before to isolate API access.
2. `npm run build`
3. Do as pleased for deployment