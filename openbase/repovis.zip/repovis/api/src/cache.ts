import { TimelinePRStats } from './interfaces';
import { parseQueryParams } from './queries';
import { log } from './config';

/**
  In Memory Caching - storage designed to persist response data from 3rd party apis between inbound client requests
*/
export class Cache {

  private data: TimelinePRStats | null = null;
  private lastCachedAt: number | null = null;

  // ttl (ms)
  constructor(private ttl: number) {}

  public set(newData: any) {
    this.lastCachedAt = new Date() as unknown as number;
    this.data = newData;
  }

  public get(years: string[]) {
    const now = new Date() as unknown as number;
    if (this.lastCachedAt && (now - this.lastCachedAt < this.ttl)) {
      return years.reduce((subsetTimeline, year) => {
        // only return data we actually have
        console.log('Checking cache now...');
        if (this.data && this.data[year]) {
          console.log('cache hit =>', year, this.data[year]);
          subsetTimeline[year] = this.data[year];
        }
        return subsetTimeline;
      }, {});
    }
    console.log('Cache busted >', this.lastCachedAt);
    return null;
  }

}

export const useCache = (cache) => (req, res, next) => {
  // return cache if possible
  const years = parseQueryParams(req.query);
  const pr_timeline = cache.get(years);
  console.log('Reading from cache...', years, pr_timeline);
  if (pr_timeline) {
    log(pr_timeline);
    console.log('Cache being used');
    res.send({ pr_timeline, shape: { YEAR: ['openedCount', 'closedCount'] } });
  } else {
    // full query
    next();
  }
};
