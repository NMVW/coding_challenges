import { TimelinePRStats, PR } from './interfaces';

export const calcPRTimeline = (prs: PR[], originalTimeline: TimelinePRStats = {}): TimelinePRStats => {

  return prs.reduce((timeline, pr) => {

    const [ yearCreated, monthCreated ] = extractYearMonth(pr.createdAt);
    const [ yearClosed, monthClosed ] = extractYearMonth(pr.closedAt);

    prepTimeline(timeline, [{year: yearCreated, month: monthCreated}, { year: yearClosed, month: monthClosed}]);

    if (doesTimeExist(timeline, yearCreated, monthCreated)) {
      // increment opened PR index
      timeline[yearCreated][monthCreated][0]++;
    }
    if (doesTimeExist(timeline, yearClosed, monthClosed)) {
      // increment closed PR index
      timeline[yearClosed][monthClosed][1]++;
    }

    return timeline;
  }, originalTimeline);
};

function doesTimeExist(timeline: TimelinePRStats, year: number, month: number) {
  if (timeline[year]) {
    return Array.isArray(timeline[year][month]);
  }
  return false;
}

function prepTimeline(timeline, times: Array<{ year: number, month: number }>): void {

  times.forEach((time) => {
    // initialize timeline
    if (time.year && time.month) {
      // init year
      if (!timeline[time.year]) {
        timeline[time.year] = [];
      }
      // init month
      if (!timeline[time.year][time.month]) {
        timeline[time.year][time.month] = [0, 0]; // [openedCount, closedCount]
      }
    }
  });

}

function extractYearMonth(dateString: string | null): [number, number] {
  if (!dateString) {
    return [NaN, NaN];
  }
  const date = new Date(dateString);
  return [date.getFullYear(), date.getUTCMonth()];
}
