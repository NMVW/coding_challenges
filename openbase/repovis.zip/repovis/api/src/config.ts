import dotenv from 'dotenv';
import util from 'util';
import { Cache, useCache as middlewareCache } from './cache';
import { gqlQuery as query } from './queries';

// load env
dotenv.config();

export const cache = new Cache(+(process.env.API_TTL || 0) as number);
export const useCache = middlewareCache(cache);

export const gqlQuery = query(process.env.GITHUB_GRAPHQL_API_URL, process.env.GITHUB_API_TOKEN, process.env.GITHUB_API_BACKOFF);

export const log = (data: any) => util.inspect(data, { depth: null, colors: true, maxArrayLength: null });

export const port = process.env.API_PORT;

export const useCors = (function (whitelisted_app_domain) {
  return (req, res, next) => {
    res.header('Access-Control-Allow-Origin', whitelisted_app_domain);
    res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');
    next();
  };
})(process.env.APP_DOMAIN);
