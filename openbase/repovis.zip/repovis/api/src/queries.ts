import fetch from 'node-fetch';
import { log } from './config';

const $order = `
  {
    direction: ASC,
    field: UPDATED_AT
  }
`;

export const pastPRs = ({ owner, name, nextCursor, size }: { owner: string, name: string, nextCursor: string | null, size: number }) => `
  {
    repo_${name}: repository(owner: "${owner}", name: "${name}") {
      prs: pullRequests(orderBy: ${$order}, last: ${size}, ${nextCursor ? `before: "${nextCursor}",`: ''} states: [OPEN, CLOSED, MERGED]) {
        list: nodes {
          createdAt
          closedAt
        }
        totalCount
        cursor: pageInfo {
          hasNext: hasPreviousPage
          next: startCursor
        }
      }
    }
  }
`;

export const parseQueryParams = (query): string[] => (query && query.years) ? query.years.split(','): [(new Date()).getFullYear()];

export const gqlQuery = (github_url, github_token, github_backoff) => {
  const headers = {
    Authorization: `Bearer ${github_token}`
  };

  // iterate through pages until all PRs covered for months of interest
  // month of createdAt - OPEN count
  // month of closedAt - CLOSED / MERGED count\
  return async (query = {}) => {
    await sleep(+(github_backoff || 5000)); // ms between calls
    log(query);
    console.log('Sending Github GraphQL Query');
    const res = await fetch(github_url as string, { headers, method: 'POST', body: JSON.stringify({ query }) });
    return res.json();
  };
};

function sleep(time: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, time));
}
