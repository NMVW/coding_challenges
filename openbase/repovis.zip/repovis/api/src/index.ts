import { gqlQuery, cache, useCache, useCors, log, port } from './config';
import { pastPRs, parseQueryParams } from './queries';
import { calcPRTimeline } from './compute';

import express from 'express';

const app = express();

app.use(useCors);

app.get('/', (req, res) => res.send('Express + TS Server'));

app.get('/github-pr-timeline', useCache, async (req, res) => {
  
  let prTimeline = {};
  let nextCursor = null;
  
  // paginate through all open / closed PRs for repo (under 1k elements, so safe to query all and hold in-memory)
  do {
    const payload = await gqlQuery(pastPRs({ owner: 'downshift-js', name: 'downshift', size: 100, nextCursor }));
    const { prs } = payload.data.repo_downshift;

    // grow existing timeline in-memory
    prTimeline = calcPRTimeline(prs.list, prTimeline);

    nextCursor = prs.cursor.next;

  } while (nextCursor);

  // cache all data for future requests
  cache.set(prTimeline);
  console.log('Full query, cache now set', cache);
  log(prTimeline);

  const pr_timeline = cache.get(parseQueryParams(req.query));
  res.send({ pr_timeline: pr_timeline, shape: { YEAR: ['openedCount', 'closedCount'] } });
});

app.listen(port, () => {
  console.log('Repovis API Server live at', port);
});