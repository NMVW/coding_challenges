export interface PR {
  createdAt: string
  closedAt: string | null
}

// JAN => 0: [openedCount, closedCount]
export type MonthPRStats = Array<[number, number]>

export interface TimelinePRStats {
  [year: number]: MonthPRStats
}
